import "dotenv/config";
import { PrismaClient } from "@prisma/client";
import { hash } from "bcryptjs";
const db = new PrismaClient();
async function main() {
  const email = process.env.SEED_ADMIN_EMAIL;
  const password = process.env.SEED_ADMIN_PASSWORD;
  if (!email || !password || password.length < 10) throw new Error("Set SEED_ADMIN_EMAIL and a SEED_ADMIN_PASSWORD of at least 12 characters");
  await db.user.upsert({ where: { email }, update: {}, create: { name: "Administrator", email, passwordHash: await hash(password, 12), role: "ADMIN" } });
  console.log(`Admin account available: ${email}`);
}
main().finally(() => db.$disconnect());
