import { z } from "zod";
export const loginSchema = z.object({ email: z.string().trim().email(), password: z.string().min(1) });
export const userSchema = z.object({ name: z.string().trim().min(2).max(100), email: z.string().trim().email().max(255), password: z.string().min(12).max(128).optional(), role: z.enum(["ADMIN", "USER"]) });
