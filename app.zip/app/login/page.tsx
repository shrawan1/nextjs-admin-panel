import { getCurrentUser } from "@/lib/auth";
import { redirect } from "next/navigation";
import { LoginForm } from "@/components/login-form";
export default async function LoginPage() { if (await getCurrentUser()) redirect("/dashboard"); return <main className="flex min-h-screen items-center justify-center p-5"><div className="card w-full max-w-md"><div className="mb-8"><div className="mb-4 inline-flex rounded-xl bg-indigo-100 px-3 py-2 font-bold text-indigo-700">A</div><h1 className="text-2xl font-bold">Welcome back</h1><p className="mt-2 text-sm text-slate-500">Sign in to your admin workspace.</p></div><LoginForm /></div></main>; }
