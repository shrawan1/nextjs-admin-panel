import { requireUser } from "@/lib/auth";
import { Sidebar } from "@/components/sidebar";
export default async function ProtectedLayout({ children }: { children: React.ReactNode }) { const user = await requireUser(); return <div className="min-h-screen md:flex"><Sidebar user={user}/><div className="min-w-0 flex-1"><header className="border-b border-slate-200 bg-white px-6 py-5"><div className="text-sm text-slate-500">Workspace / Admin</div></header><main className="mx-auto max-w-6xl p-6 md:p-10">{children}</main></div></div>; }
