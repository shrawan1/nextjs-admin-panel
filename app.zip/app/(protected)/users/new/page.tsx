import { requireAdmin } from "@/lib/auth";
import { UserForm } from "@/components/user-form";
export default async function NewUser() { await requireAdmin(); return <div className="space-y-6"><h1 className="text-3xl font-bold">Add user</h1><UserForm/></div>; }
