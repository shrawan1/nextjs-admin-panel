import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/db";
import { notFound } from "next/navigation";
import { UserForm } from "@/components/user-form";
export default async function EditUser({ params }: { params: Promise<{ id: string }> }) { await requireAdmin(); const { id } = await params; const user = await db.user.findUnique({ where: { id }, select: { id: true, name: true, email: true, role: true } }); if (!user) notFound(); return <div className="space-y-6"><h1 className="text-3xl font-bold">Edit user</h1><UserForm user={user}/></div>; }
