import "./globals.css";
export const metadata = { title: "Admin Panel", description: "Next.js full-stack admin dashboard" };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body>{children}</body></html>; }
