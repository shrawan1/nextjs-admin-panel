"use server";
import { db } from "@/lib/db";
import { clearSession, createSession, requireAdmin, requireUser } from "@/lib/auth";
import { loginSchema, userSchema } from "@/lib/validation";
import { compare, hash } from "bcryptjs";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
export type ActionState = { error: string };
export async function login(_previous: ActionState, formData: FormData): Promise<ActionState> {
  const parsed = loginSchema.safeParse({ email: formData.get("email"), password: formData.get("password") });
  if (!parsed.success) return { error: "Enter a valid email and password." };
  const user = await db.user.findUnique({ where: { email: parsed.data.email } });
  if (!user || !(await compare(parsed.data.password, user.passwordHash))) return { error: "Invalid email or password." };
  await createSession(user.id);
  redirect("/dashboard");
}
export async function logout() { await clearSession(); redirect("/login"); }
export async function createUser(_previous: ActionState, formData: FormData): Promise<ActionState> {
  await requireAdmin();
  const parsed = userSchema.safeParse({ name: formData.get("name"), email: formData.get("email"), password: formData.get("password"), role: formData.get("role") });
  if (!parsed.success || !parsed.data.password) return { error: "Enter a valid name, email, role and password (12+ characters)." };
  const existing = await db.user.findUnique({ where: { email: parsed.data.email } });
  if (existing) return { error: "Email already exists." };
  await db.user.create({ data: { name: parsed.data.name, email: parsed.data.email, role: parsed.data.role, passwordHash: await hash(parsed.data.password, 12) } });
  revalidatePath("/users"); revalidatePath("/dashboard"); redirect("/users");
}
export async function updateUser(id: string, _previous: ActionState, formData: FormData): Promise<ActionState> {
  const actor = await requireAdmin();
  const rawPassword = String(formData.get("password") ?? "");
  const parsed = userSchema.safeParse({ name: formData.get("name"), email: formData.get("email"), role: formData.get("role"), password: rawPassword || undefined });
  if (!parsed.success) return { error: "Invalid fields. New passwords must be at least 12 characters." };
  const target = await db.user.findUnique({ where: { id } });
  if (!target) return { error: "User not found." };
  if (actor.id === id && parsed.data.role !== "ADMIN") return { error: "You cannot remove your own admin role." };
  const duplicate = await db.user.findUnique({ where: { email: parsed.data.email } });
  if (duplicate && duplicate.id !== id) return { error: "Email already exists." };
  await db.user.update({ where: { id }, data: { name: parsed.data.name, email: parsed.data.email, role: parsed.data.role, ...(rawPassword ? { passwordHash: await hash(rawPassword, 12) } : {}) } });
  revalidatePath("/users"); revalidatePath("/dashboard"); redirect("/users");
}
export async function deleteUser(formData: FormData) {
  const actor = await requireAdmin();
  const id = String(formData.get("id") ?? "");
  if (id === actor.id) return;
  await db.user.deleteMany({ where: { id } });
  revalidatePath("/users"); revalidatePath("/dashboard");
}
