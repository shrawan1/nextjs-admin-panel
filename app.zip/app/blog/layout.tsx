import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { Sidebar } from "@/components/sidebar";

export default async function BlogLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getCurrentUser();

  // Check Login
  if (!user) {
    redirect("/");
  }

  // Only Admin Access
  if (user.role !== "ADMIN") {
    redirect("/dashboard");
  }

  return (
    <div className="min-h-screen bg-slate-50 md:flex">
      {/* Admin Sidebar */}
      <Sidebar
        user={{
          name: user.name,
          email: user.email,
          role: user.role,
        }}
      />

      {/* Main Section */}
      <div className="min-w-0 flex-1">
        {/* Header */}
        <header className="flex h-[73px] items-center border-b border-slate-200 bg-white px-8">
          <p className="text-sm text-slate-500">
            Workspace / Admin
          </p>
        </header>

        {/* Blog Content */}
        <main>{children}</main>
      </div>
    </div>
  );
}
