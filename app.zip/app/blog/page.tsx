
import Link from "next/link";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";

interface Blog {
  id: number;
  title: string;
  url: string;
  description: string;
  img: string | null;
  date: string | Date;
}

// Delete Blog
async function deleteBlog(formData: FormData) {
  "use server";

  const user = await getCurrentUser();

  if (!user || user.role !== "ADMIN") {
    throw new Error("Unauthorized");
  }

  const id = Number(formData.get("id"));

  if (!Number.isSafeInteger(id) || id <= 0) {
    throw new Error("Invalid blog ID");
  }

  await db.$executeRaw`
    DELETE FROM blogs WHERE id = ${id}
  `;

  revalidatePath("/blog");
}

export default async function BlogPage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect("/");
  }

  if (user.role !== "ADMIN") {
    redirect("/dashboard");
  }

  // Fetch blogs directly from MySQL
  const blogs = await db.$queryRaw<Blog[]>`
    SELECT id, title, url, description, img, date
    FROM blogs
    ORDER BY id DESC
  `;

  return (
    <div className="mx-auto max-w-7xl p-6 md:p-10">
      <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-950">
            Blogs
          </h1>
          <p className="mt-2 text-slate-500">
            Manage your blog posts and content.
          </p>
        </div>

        <Link
          href="/blog/create"
          className="rounded-lg bg-indigo-600 px-5 py-3 text-sm font-semibold text-white hover:bg-indigo-700"
        >
          + Add Blog
        </Link>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500">
                <th className="px-3 py-4">ID</th>
                <th className="px-3 py-4">Title</th>
                <th className="px-3 py-4">URL</th>
                <th className="px-3 py-4">Description</th>
                <th className="px-3 py-4">Image</th>
                <th className="px-3 py-4">Date</th>
                <th className="px-3 py-4">Actions</th>
              </tr>
            </thead>

            <tbody>
              {blogs.map((blog) => (
                <tr
                  key={blog.id}
                  className="border-b border-slate-100 last:border-0"
                >
                  <td className="px-3 py-4">
                    {blog.id}
                  </td>

                  <td className="px-3 py-4 font-medium text-slate-950">
                    {blog.title}
                  </td>

                  <td className="px-3 py-4 text-slate-600">
                    {blog.url}
                  </td>

                  <td className="max-w-[220px] px-3 py-4 text-slate-600">
                    <p className="line-clamp-2">
                      {blog.description}
                    </p>
                  </td>

                  
<td className="px-3 py-4">
  {blog.img ? (
    <img
      src={blog.img}
      alt={blog.title}
      className="h-16 w-24 rounded-lg border border-slate-200 object-cover"
      loading="lazy"
    />
  ) : (
    <span className="text-slate-400">No Image</span>
  )}
</td>


                  <td className="whitespace-nowrap px-3 py-4 text-slate-600">
                    {blog.date
                      ? new Date(blog.date).toLocaleDateString("en-US")
                      : "—"}
                  </td>

                  <td className="px-3 py-4">
                    <div className="flex items-center gap-3">
                      <Link
                        href={`/blog/${blog.id}/edit`}
                        className="font-medium text-indigo-600 hover:underline"
                      >
                        Edit
                      </Link>

                      <form action={deleteBlog}>
                        <input
                          type="hidden"
                          name="id"
                          value={blog.id}
                        />
                        <button
                          type="submit"
                          className="font-medium text-red-600 hover:underline"
                        >
                          Delete
                        </button>
                      </form>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {blogs.length === 0 && (
            <p className="py-12 text-center text-slate-500">
              No blogs found. Click Add Blog to create one.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
