
import Link from "next/link";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";

async function createBlog(formData: FormData) {
  "use server";

  // Admin authentication
  const user = await getCurrentUser();

  if (!user || user.role !== "ADMIN") {
    throw new Error("Unauthorized access");
  }

  const title = String(formData.get("title") ?? "").trim();
  const url = String(formData.get("url") ?? "").trim();
  const description = String(
    formData.get("description") ?? ""
  ).trim();
  const img = String(formData.get("img") ?? "").trim();
  const date = String(formData.get("date") ?? "").trim();

  // Validate fields
  if (!title || !url || !description || !date) {
    throw new Error("Please fill all required fields.");
  }

  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(url)) {
    throw new Error(
      "URL must contain lowercase letters, numbers and hyphens only."
    );
  }

  if (
    !/^\d{4}-\d{2}-\d{2}$/.test(date) ||
    Number.isNaN(Date.parse(date))
  ) {
    throw new Error("Invalid date.");
  }

  // Insert into existing MySQL blogs table
  // The date column is assumed to be DATE type.
  await db.$executeRaw`
    INSERT INTO blogs (title, url, description, img, date)
    VALUES (
      ${title},
      ${url},
      ${description},
      ${img},
      ${date}
    )
  `;

  revalidatePath("/blog");
  redirect("/blog");
}

export default async function CreateBlogPage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect("/");
  }

  if (user.role !== "ADMIN") {
    redirect("/dashboard");
  }

  const today = new Date().toLocaleDateString("en-CA");

  return (
    <div className="mx-auto max-w-7xl p-6 md:p-10">
      {/* Heading */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-950">
          Add New Blog
        </h1>

        <p className="mt-2 text-slate-500">
          Create and publish a new blog post.
        </p>
      </div>

      {/* Add Blog Form */}
      <div className="max-w-4xl rounded-2xl border border-slate-200 bg-white p-6 shadow-sm md:p-8">
        <form action={createBlog} className="space-y-6">

          {/* Blog Title */}
          <div>
            <label
              htmlFor="title"
              className="mb-2 block text-sm font-semibold text-slate-700"
            >
              Blog Title *
            </label>

            <input
              id="title"
              type="text"
              name="title"
              placeholder="Enter blog title"
              required
              maxLength={255}
              className="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm outline-none focus:border-indigo-500"
            />
          </div>

          {/* Blog URL */}
          <div>
            <label
              htmlFor="url"
              className="mb-2 block text-sm font-semibold text-slate-700"
            >
              Blog URL / Slug *
            </label>

            <input
              id="url"
              type="text"
              name="url"
              placeholder="example-blog-title"
              required
              pattern="[a-z0-9]+(-[a-z0-9]+)*"
              maxLength={255}
              className="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm outline-none focus:border-indigo-500"
            />

            <p className="mt-2 text-xs text-slate-500">
              Example: how-to-create-a-blog
            </p>
          </div>

          {/* Description */}
          <div>
            <label
              htmlFor="description"
              className="mb-2 block text-sm font-semibold text-slate-700"
            >
              Blog Description / Content *
            </label>

            <textarea
              id="description"
              name="description"
              rows={10}
              placeholder="Write your blog content here..."
              required
              className="w-full resize-y rounded-lg border border-slate-300 px-4 py-3 text-sm outline-none focus:border-indigo-500"
            />
          </div>

          {/* Blog Image */}
          <div>
            <label
              htmlFor="img"
              className="mb-2 block text-sm font-semibold text-slate-700"
            >
              Featured Image URL
            </label>

            <input
              id="img"
              type="text"
              name="img"
              placeholder="/uploads/blog-image.jpg"
              className="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm outline-none focus:border-indigo-500"
            />

            <p className="mt-2 text-xs text-slate-500">
              Enter an image URL or an existing image path.
            </p>
          </div>

          {/* Date */}
          <div>
            <label
              htmlFor="date"
              className="mb-2 block text-sm font-semibold text-slate-700"
            >
              Publish Date *
            </label>

            <input
              id="date"
              type="date"
              name="date"
              defaultValue={today}
              required
              className="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm outline-none focus:border-indigo-500"
            />
          </div>

          {/* Buttons */}
          <div className="flex justify-end gap-3 border-t border-slate-200 pt-6">
            <Link
              href="/blog"
              className="rounded-lg border border-slate-300 px-6 py-3 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </Link>

            <button
              type="submit"
              className="rounded-lg bg-indigo-600 px-6 py-3 text-sm font-semibold text-white hover:bg-indigo-700"
            >
              Save Blog
            </button>
          </div>

        </form>
      </div>
    </div>
  );
}
