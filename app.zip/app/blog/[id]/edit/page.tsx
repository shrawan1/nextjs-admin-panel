
import Link from "next/link";
import { redirect, notFound } from "next/navigation";
import { revalidatePath } from "next/cache";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";

interface Blog {
  id: number;
  title: string;
  url: string;
  description: string;
  img: string | null;
  date: Date | string;
}

// Update blog in MySQL
async function updateBlog(formData: FormData) {
  "use server";

  const user = await getCurrentUser();

  if (!user || user.role !== "ADMIN") {
    throw new Error("Unauthorized access");
  }

  const id = Number(formData.get("id"));
  const title = String(formData.get("title") ?? "").trim();
  const url = String(formData.get("url") ?? "").trim();
  const description = String(
    formData.get("description") ?? ""
  ).trim();
  const img = String(formData.get("img") ?? "").trim();
  const date = String(formData.get("date") ?? "").trim();

  if (!Number.isSafeInteger(id) || id <= 0) {
    throw new Error("Invalid blog ID");
  }

  if (!title || !url || !description || !date) {
    throw new Error("Please fill all required fields");
  }

  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(url)) {
    throw new Error("Invalid URL slug");
  }

  if (
    !/^\d{4}-\d{2}-\d{2}$/.test(date) ||
    Number.isNaN(Date.parse(date))
  ) {
    throw new Error("Invalid date");
  }

  // Update existing record using Prisma
  const affectedRows = await db.$executeRaw`
    UPDATE blogs
    SET
      title = ${title},
      url = ${url},
      description = ${description},
      img = ${img},
      date = ${date}
    WHERE id = ${id}
  `;

  if (affectedRows === 0) {
    throw new Error("Blog not found or no changes saved");
  }

  revalidatePath("/blog");
  redirect("/blog");
}

export default async function EditBlogPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const user = await getCurrentUser();

  if (!user) redirect("/");
  if (user.role !== "ADMIN") redirect("/dashboard");

  const { id } = await params;
  const blogId = Number(id);

  if (!Number.isSafeInteger(blogId) || blogId <= 0) {
    notFound();
  }

  // Fetch existing blog from database
  const blogs = await db.$queryRaw<Blog[]>`
    SELECT id, title, url, description, img, date
    FROM blogs
    WHERE id = ${blogId}
    LIMIT 1
  `;

  if (!blogs.length) {
    notFound();
  }

  const blog = blogs[0];

  // Format date for HTML input
  const formattedDate =
    blog.date instanceof Date
      ? blog.date.toISOString().slice(0, 10)
      : String(blog.date).slice(0, 10);

  return (
    <div className="mx-auto max-w-7xl p-6 md:p-10">
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-950">
          Edit Blog
        </h1>

        <p className="mt-2 text-slate-500">
          Update your existing blog details.
        </p>
      </div>

      {/* Edit Blog Form */}
      <div className="max-w-4xl rounded-2xl border border-slate-200 bg-white p-6 shadow-sm md:p-8">
        <form action={updateBlog} className="space-y-6">
          <input type="hidden" name="id" value={blog.id} />

          {/* Blog Title */}
          <div>
            <label
              htmlFor="title"
              className="mb-2 block text-sm font-semibold text-slate-700"
            >
              Blog Title *
            </label>

            <input
              id="title"
              type="text"
              name="title"
              defaultValue={blog.title}
              required
              maxLength={255}
              className="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm outline-none focus:border-indigo-500"
            />
          </div>

          {/* URL Slug */}
          <div>
            <label
              htmlFor="url"
              className="mb-2 block text-sm font-semibold text-slate-700"
            >
              Blog URL / Slug *
            </label>

            <input
              id="url"
              type="text"
              name="url"
              defaultValue={blog.url}
              required
              maxLength={255}
              pattern="[a-z0-9]+(-[a-z0-9]+)*"
              className="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm outline-none focus:border-indigo-500"
            />
          </div>

          {/* Description */}
          <div>
            <label
              htmlFor="description"
              className="mb-2 block text-sm font-semibold text-slate-700"
            >
              Blog Description / Content *
            </label>

            <textarea
              id="description"
              name="description"
              defaultValue={blog.description}
              rows={10}
              required
              className="w-full resize-y rounded-lg border border-slate-300 px-4 py-3 text-sm outline-none focus:border-indigo-500"
            />
          </div>

          {/* Image */}
          <div>
            <label
              htmlFor="img"
              className="mb-2 block text-sm font-semibold text-slate-700"
            >
              Featured Image
            </label>

            {blog.img && (
              <div className="mb-4">
                <img
                  src={
                    blog.img.startsWith("/uploads/")
                      ? blog.img
                      : `/uploads/${blog.img.replace(/^\/+/, "")}`
                  }
                  alt={blog.title}
                  className="h-32 w-48 rounded-lg border border-slate-200 object-cover"
                />
                <p className="mt-2 text-xs text-slate-500">
                  Current blog image
                </p>
              </div>
            )}

            <input
              id="img"
              type="text"
              name="img"
              defaultValue={blog.img ?? ""}
              placeholder="/uploads/blog-image.jpg"
              className="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm outline-none focus:border-indigo-500"
            />

            <p className="mt-2 text-xs text-slate-500">
              Enter the image filename or path from public/uploads.
            </p>
          </div>

          {/* Date */}
          <div>
            <label
              htmlFor="date"
              className="mb-2 block text-sm font-semibold text-slate-700"
            >
              Publish Date *
            </label>

            <input
              id="date"
              type="date"
              name="date"
              defaultValue={formattedDate}
              required
              className="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm outline-none focus:border-indigo-500"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-3 border-t border-slate-200 pt-6">
            <Link
              href="/blog"
              className="rounded-lg border border-slate-300 px-6 py-3 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </Link>

            <button
              type="submit"
              className="rounded-lg bg-indigo-600 px-6 py-3 text-sm font-semibold text-white hover:bg-indigo-700"
            >
              Update Blog
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
