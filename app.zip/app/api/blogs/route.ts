const result = await db.$executeRaw`
  INSERT INTO blogs (title, url, description, img, date)
  VALUES (
    ${title},
    ${url},
    ${description},
    ${img},
    ${date}
  )
`;