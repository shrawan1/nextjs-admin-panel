"use client";
import { useActionState } from "react";
import { login } from "@/app/actions";
export function LoginForm() { const [state, action, pending] = useActionState(login, { error: "" }); return <form action={action} className="space-y-4"><label className="label">Email<input name="email" type="email" autoComplete="email" required className="input" /></label><label className="label">Password<input name="password" type="password" autoComplete="current-password" required className="input" /></label>{state.error && <p role="alert" className="text-sm text-red-600">{state.error}</p>}<button disabled={pending} className="btn w-full">{pending ? "Signing in…" : "Sign in"}</button></form>; }
