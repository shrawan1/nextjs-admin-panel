
import Link from "next/link";
import {
  LayoutDashboard,
  Users,
  ShieldCheck,
  FileText,
} from "lucide-react";
import { logout } from "@/app/actions";

export function Sidebar({
  user,
}: {
  user: {
    name: string;
    email: string;
    role: string;
  };
}) {
  return (
    <aside className="w-full border-b border-slate-200 bg-white p-5 md:min-h-screen md:w-64 md:border-b-0 md:border-r">
      <div className="mb-8 flex items-center gap-3">
        <div className="rounded-xl bg-indigo-600 px-3 py-2 font-bold text-white">
          A
        </div>
        <span className="text-lg font-bold">AdminSpace</span>
      </div>

      <nav className="flex gap-2 md:flex-col">
        {/* Dashboard */}
        <Link
          className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-slate-700 hover:bg-indigo-50"
          href="/dashboard"
        >
          <LayoutDashboard size={18} />
          Dashboard
        </Link>

        {user.role === "ADMIN" && (
          <>
            {/* Users */}
            <Link
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-slate-700 hover:bg-indigo-50"
              href="/users"
            >
              <Users size={18} />
              Users
            </Link>

            {/* Blogs */}
            <Link
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-slate-700 hover:bg-indigo-50"
              href="/blog"
            >
              <FileText size={18} />
              Blogs
            </Link>
          </>
        )}
      </nav>

      <div className="mt-10 border-t pt-5">
        <p className="flex items-center gap-2 text-sm font-semibold">
          <ShieldCheck
            size={16}
            className="text-indigo-600"
          />
          {user.name}
        </p>

        <p className="mt-1 truncate text-xs text-slate-500">
          {user.email}
        </p>

        <form action={logout}>
          <button className="mt-4 text-sm font-medium text-red-600 hover:underline">
            Sign out
          </button>
        </form>
      </div>
    </aside>
  );
}
